package com.tnsif.customer1;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class B76Customer1Application {
	public static void main(String[] args) 
	{
		SpringApplication.run(B76Customer1Application.class, args);
	}
}
