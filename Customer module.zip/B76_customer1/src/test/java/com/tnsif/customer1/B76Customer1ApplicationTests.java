package com.tnsif.customer1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class B76Customer1ApplicationTests {

	@Test
	void contextLoads() 
	{
	}

}
